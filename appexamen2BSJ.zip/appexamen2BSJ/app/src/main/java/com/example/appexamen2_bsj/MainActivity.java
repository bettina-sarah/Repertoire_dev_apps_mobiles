package com.example.appexamen2_bsj;

import androidx.annotation.OptIn;
import androidx.appcompat.app.AppCompatActivity;
import androidx.media3.common.MediaItem;
import androidx.media3.common.util.UnstableApi;
import androidx.media3.exoplayer.ExoPlayer;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class MainActivity extends AppCompatActivity { //implements JSONObserver

    Button polonais;
    Button roumain;
    Button portugais;
    TextView annee;
    String anneeEnregistrement;
    ExoPlayer player;
    Ecouteur listener;

    RequestQueue requestQueue;
    String jsonUrl;
    JsonObjectRequest jsonRequest;

    //private JSONObserver jsonObserver;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        polonais = findViewById(R.id.polonais);
        roumain = findViewById(R.id.roumain);
        portugais = findViewById(R.id.portugais);

        annee = findViewById(R.id.annee);


        player = new ExoPlayer.Builder(this).build();

        openJSON();

        listener = new Ecouteur();
        polonais.setOnClickListener(listener);
        roumain.setOnClickListener(listener);
        portugais.setOnClickListener(listener);

    }

    public void openJSON (){

        requestQueue = Volley.newRequestQueue(MainActivity.this);
        jsonUrl = "https://api.jsonbin.io/v3/b/66378950e41b4d34e4ef1d39?meta=false";

        jsonRequest = new JsonObjectRequest(Request.Method.GET, jsonUrl,null,new Response.Listener<JSONObject>(){
            @OptIn(markerClass = UnstableApi.class) @Override // ajouté pour permettre a setter le player
            //pour qu'il arrete apres chaque mp3 !
            public void onResponse(JSONObject response) {
                try {
                    JSONArray merci = response.getJSONArray("remerciements");
                    System.out.println("**** !!! JSON REVENU VOICI ARRAY"+merci.get(1));
                    for(int i=0; i<merci.length(); i++){
                        player.addMediaItem(MediaItem.fromUri(merci.getJSONObject(i).getString("source")));
                        //jsonObserver.changement();
                        player.seekTo(1,0);
                        //anneeEnregistrement = String.valueOf(player.getMediaMetadata().recordingYear);
                    }
                    player.prepare();
                    player.setPauseAtEndOfMediaItems(true); //arret apres chaque mp3
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Log.i("erreur!!", error.toString());

            }});

        this.requestQueue.add(jsonRequest);

    }

//    @Override
//    public void changement() {
//        player.seekTo(1,0);
//        anneeEnregistrement = String.valueOf(player.getMediaMetadata().recordingYear);
//    }

    //public void avertitObservateurs(JSONObserver observer) {
//        observer.changement();
//    }

    private class Ecouteur implements View.OnClickListener {

        //annee se update trop tard. peut-etre un observer

            public void onClick(View source) {
            if(source==polonais){
                player.seekTo(0,0);
                player.play();
                String anneee = String.valueOf(player.getMediaMetadata().recordingYear);
                annee.setText(anneee);
            }
            else if(source==roumain){
                player.seekTo(1,0);
                player.play();
                String anneee = String.valueOf(player.getMediaMetadata().recordingYear);
                annee.setText(anneee);
            }
            else if(source==portugais){
                player.seekTo(2,0);
                player.play();
                String anneee = String.valueOf(player.getMediaMetadata().recordingYear);
                annee.setText(anneee);

            }
        }
    }
//    public interface JSONObserver {
//        public void changement();
//    }
}